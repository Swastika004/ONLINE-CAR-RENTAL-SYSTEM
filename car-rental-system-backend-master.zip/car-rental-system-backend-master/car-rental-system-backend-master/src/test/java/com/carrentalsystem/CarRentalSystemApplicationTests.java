package com.carrentalsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
