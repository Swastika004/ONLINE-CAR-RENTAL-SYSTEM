package com.carrentalsystem.resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class PaymentResource {
	
	private final Logger LOG = LoggerFactory.getLogger(PaymentResource.class);

}
